SICILIA, SCEGLI IL TUO FUTURO — sito iniziale

- index.html: sito statico responsive.
- Pulsante petizione collegato a https://c.org/sNMfDbbCZn
- Il sito non raccoglie direttamente dati personali o firme.

Pubblicazione semplice da telefono con GitHub Pages:
1. Crea/accedi a un account su https://github.com
2. Crea un repository pubblico, ad esempio sicilia-scegli-il-tuo-futuro.
3. Usa Add file > Upload files e carica index.html nella cartella principale.
4. Apri Settings > Pages; sotto Build and deployment scegli Deploy from a branch, branch main, folder /(root), quindi Save.
5. Attendi la pubblicazione e apri l'indirizzo mostrato da GitHub Pages.

Nota: i siti GitHub Pages sono pubblici. Non caricare dati personali, credenziali o documenti privati. Le adesioni su una piattaforma privata non equivalgono automaticamente a firme ufficiali per referendum o iniziative legislative.
